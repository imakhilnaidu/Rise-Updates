from django import forms
from uploads.core.models import Document
