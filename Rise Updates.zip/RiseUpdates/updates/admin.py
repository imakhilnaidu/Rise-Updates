from django.contrib import admin

# Register your models here.
from .models import Updatedata, Prakasam, Gandhi, Polytechnic

admin.site.register(Updatedata)
admin.site.register(Prakasam)
admin.site.register(Gandhi)
admin.site.register(Polytechnic)
